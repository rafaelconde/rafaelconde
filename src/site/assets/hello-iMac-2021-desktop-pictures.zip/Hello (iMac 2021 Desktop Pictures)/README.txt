Follow these steps to add these wallpapers to the default "Desktop & Screen Saver" system preferences pane:

1. Open a new Finder window.
2. Press ⌘⇧G to open the "Go to Folder…" window and type "/Library/Desktop Pictures/" and hit return.
3. Move all the desktop pictures that you just downloaded to this folder, next time you'll open System Preferences they should be in the "Light and Dark Desktop" section of "Desktop Pictures" section  ✨
